const express = require('express');
const router = express.Router();

router.get('/', async (req, res) => {
    res.json([
        { name: 'GDP Growth', value: 2.5, unit: '%' },
        { name: 'Inflation Rate', value: 3.1, unit: '%' },
        { name: 'Unemployment Rate', value: 5.4, unit: '%' }
    ]);
});

module.exports = router;
